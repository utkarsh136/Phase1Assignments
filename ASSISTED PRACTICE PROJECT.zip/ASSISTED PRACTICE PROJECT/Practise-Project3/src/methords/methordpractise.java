package methords;

public class methordpractise {
	public int add(int a,int b) {// SIMPLE ADD METHORD
		int c=a+b;
		return c;
		
		
	}
	public int multiply(int a,int b) {// Methord overloading
		int c=a*b;
		return c;
	}
	public static void main(String[] args) {
		methordpractise j= new methordpractise();
		int p=j.add(10,5);
		int k=j.multiply(67, 89);
		System.out.println(p);
		System.out.println(k);
		System.out.println(j.add(67,89));//call by value
				
		
		
		// TODO Auto-generated method stub

	}

}
